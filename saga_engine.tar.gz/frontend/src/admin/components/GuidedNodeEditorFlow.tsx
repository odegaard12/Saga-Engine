import { useEffect, useMemo, useState } from 'react'
import QrCardStudio, { getQrDesignSignature, type QrCardDesign } from './QrCardStudio'
import {
  adminGameCatalog,
  getAdminGame,
  getDefaultAdminStagePatchForGame,
  type AdminGameCatalogItem,
  type AdminGameId,
} from '../lib/gameCatalog'
import type { SavedPhysicalQrCard, PhysicalQrKind } from './PhysicalQrCardsPanel'
import CircuitPatternEditor from './circuitPattern/CircuitPatternEditor'
import SequenceCodeEditor from './sequenceCode/SequenceCodeEditor'
import PlaceMosaicEditor from './placeMosaic/PlaceMosaicEditor'
import TiltMazeEditor from './tiltMaze/TiltMazeEditor'

import {
  type StageLike,
  type StepKey,
  type EditorMode,
  STEPS,
  READY_STATUSES,
  TECHNICAL_CONFIG_KEYS,
  LEGACY_MESSAGE_FALLBACKS,
  QR_KIND_BY_GAME_ID,
  QR_GAME_BY_KIND,
  CONFIG_FIELD_META,
  CONFIG_ORDER,
  configOf,
  titleOf,
  nodeNumber,
  displayTitle,
  normalizeQrKind,
  hasExplicitQrMarker,
  gameFromStage,
  isMapCollectibleStage,
  isQrStage,
  gameOptions,
  qrOptions,
  statusLabel,
  offlineLabel,
  isPlayableNow,
  usesLocationRadius,
  normalizeDifficultyForEditor,
  isValidFixedCircuitConfig,
  isValidSequenceCodeConfig,
  isValidTiltMazeConfig,
  isValidPlaceMosaicConfig,
  normalizeCopy,
  shouldReplaceGeneratedGameTitle,
  shouldReplaceSequenceTitle,
  shouldReplacePlaceMosaicTitle,
  isLegacySequenceCopy,
  isLegacySequenceHint,
  isExperimentalOrPlanned,
  normalizeMessage,
  CUSTOM_GAME_EDITOR_IDS,
  hasCustomGameEditor,
  guidedConfigKeysForGame,
  slugOf,
  fallbackCode,
  qrKindForGame,
  qrGameForKind,
  qrLabel,
  qrItemId,
  qrPayload,
  qrDesignFromConfig,
  formatConfigValue,
  parseConfigValue,
  copyText
} from './guided-editor/guidedEditorUtils'
export default function GuidedNodeEditorFlow({
  stage,
  onPatch,
  onClose,
  onDelete,
  onRequestChangeType,
}: GuidedNodeEditorFlowProps) {
  const [stepIndex, setStepIndex] = useState(0)
  const [notice, setNotice] = useState<string | null>(null)
  const [showExperimentalGames, setShowExperimentalGames] = useState(false)
  const [editorMode, setEditorMode] = useState<EditorMode>(() =>
    isMapCollectibleStage(stage) ? 'map_collectible' : isQrStage(stage) ? 'qr' : 'game'
  )

  useEffect(() => {
    setEditorMode(
      isMapCollectibleStage(stage) ? 'map_collectible' : isQrStage(stage) ? 'qr' : 'game'
    )
    setStepIndex(0)
  }, [stage.id, stage.index])

  const mode = editorMode
  const selected = gameFromStage(stage)
  const selectedQr =
    mode === 'qr' && selected.category === 'physical'
      ? selected
      : qrGameForKind(normalizeQrKind(stage.physical_node_kind || stage.physical_item_kind))
  const selectedGame =
    mode === 'game' && selected.category !== 'physical'
      ? selected
      : gameOptions(showExperimentalGames)[0]
  const step = STEPS[stepIndex]?.key || 'subtype'
  const title = displayTitle(stage)
  const config = configOf(stage)
  const qrDesign = qrDesignFromConfig(config)

  const qrDesignSignature = getQrDesignSignature(qrPayload(stage), qrDesign)

  const qrValidated = String(config.qr_validation_signature || '') === qrDesignSignature

  const customGameEditor = mode === 'game' && hasCustomGameEditor(selectedGame)

  const progress = useMemo(() => Math.round(((stepIndex + 1) / STEPS.length) * 100), [stepIndex])

  const goNext = () => setStepIndex((value) => Math.min(value + 1, STEPS.length - 1))
  const goBack = () => setStepIndex((value) => Math.max(value - 1, 0))
  const goTo = (key: StepKey) =>
    setStepIndex(
      Math.max(
        0,
        STEPS.findIndex((item) => item.key === key)
      )
    )

  function showNotice(message: string) {
    setNotice(message)
    window.setTimeout(() => setNotice(null), 1800)
  }

  function patchConfig(key: string, value: string) {
    const nextConfig = {
      ...config,
      [key]: parseConfigValue(key, value),
    }
    onPatch({
      config: nextConfig,
      objective: key === 'objective' ? value : stage.objective,
    })
  }

  function applyGame(game: AdminGameCatalogItem) {
    setEditorMode('game')
    const base = getDefaultAdminStagePatchForGame(game.id)
    const nextConfig = {
      ...(base.config || {}),
      game_id: game.id,
      game_title: game.title,
      completion_method: game.completionMethod,
    }

    const defaultTitle =
      game.id === 'sequence_code'
        ? 'La clave del tríptico'
        : game.id === 'place_mosaic'
          ? 'Mosaico del lugar'
          : game.id === 'tilt_maze'
            ? 'Laberinto de equilibrio'
            : game.id === 'logic_circuit'
              ? 'Matriz de circuitos'
              : game.title

    const nextTitle = shouldReplaceGeneratedGameTitle(stage.title) ? defaultTitle : stage.title

    onPatch({
      ...base,
      title: nextTitle,
      _clear_physical_fields: true,
      physical_qr: null,
      physical_node_kind: null,
      physical_item_kind: null,
      physical_item_id: '',
      physical_item_label: '',
      qr_payload: '',
      game_family: game.family,
      game_type: game.id,
      game_template_id: game.id,
      completion_method: game.completionMethod,
      entry_mode:
        game.completionMethod === 'bearing'
          ? 'bearing'
          : game.completionMethod === 'manual_code'
            ? 'manual'
            : game.category === 'motion' ||
                game.completionMethod === 'motion' ||
                game.category === 'logic'
              ? 'free'
              : 'gps',
      requires_proximity: !(
        game.category === 'logic' ||
        game.category === 'motion' ||
        game.completionMethod === 'motion'
      ),
      radius_m: Number(stage.radius_m || stage.proximity_radius_m || stage.radius || 50),
      proximity_radius_m: Number(stage.proximity_radius_m || stage.radius_m || stage.radius || 50),
      config: nextConfig,
      messages: game.messages,
      content: game.content,
      description: game.content,
    })
    goTo('config')
  }

  function finalizeAndClose() {
    if (mode === 'game' && selectedGame.id === 'tilt_maze' && !isValidTiltMazeConfig(config)) {
      showNotice('Revisa tamaño, tiempo y vidas del laberinto.')
      goTo('config')
      return
    }

    if (
      mode === 'game' &&
      selectedGame.id === 'place_mosaic' &&
      !isValidPlaceMosaicConfig(config)
    ) {
      showNotice('Sube una fotografía y revisa la pregunta final.')
      goTo('config')
      return
    }

    if (
      mode === 'game' &&
      selectedGame.id === 'sequence_code' &&
      !isValidSequenceCodeConfig(config)
    ) {
      showNotice('La secuencia necesita entre 3 y 10 fichas diferentes.')
      goTo('config')
      return
    }

    if (
      mode === 'game' &&
      selectedGame.id === 'logic_circuit' &&
      !isValidFixedCircuitConfig(config)
    ) {
      showNotice('El patrón fijo está incompleto o contiene saltos.')
      goTo('config')
      return
    }

    if (mode === 'game') {
      const base = getDefaultAdminStagePatchForGame(selectedGame.id)
      const nextConfig = {
        ...(base.config || {}),
        ...config,
        is_map_collectible: false,
        game_id: selectedGame.id,
        game_title: selectedGame.title,
        completion_method: selectedGame.completionMethod,
      }

      const rawContent = String(stage.content || stage.description || selectedGame.content || '')

      const nextContent =
        selectedGame.id === 'sequence_code' && isLegacySequenceCopy(rawContent)
          ? selectedGame.content
          : rawContent || selectedGame.content

      const currentMessages = stage.messages || selectedGame.messages

      const nextMessages =
        selectedGame.id === 'sequence_code' && isLegacySequenceHint(currentMessages?.hint)
          ? selectedGame.messages
          : currentMessages

      const nextTitle =
        selectedGame.id === 'sequence_code' && shouldReplaceSequenceTitle(stage.title)
          ? 'La clave del tríptico'
          : selectedGame.id === 'place_mosaic' && shouldReplacePlaceMosaicTitle(stage.title)
            ? 'Mosaico del lugar'
            : stage.title

      onPatch({
        ...base,
        _clear_physical_fields: true,
        physical_qr: null,
        physical_node_kind: null,
        physical_item_kind: null,
        physical_item_id: '',
        physical_item_label: '',
        qr_payload: '',
        game_family: selectedGame.family,
        game_type: selectedGame.id,
        game_template_id: selectedGame.id,
        completion_method: selectedGame.completionMethod,
        entry_mode:
          selectedGame.completionMethod === 'bearing'
            ? 'bearing'
            : selectedGame.completionMethod === 'manual_code'
              ? 'manual'
              : selectedGame.category === 'motion' ||
                  selectedGame.completionMethod === 'motion' ||
                  selectedGame.category === 'logic'
                ? 'free'
                : 'gps',
        requires_proximity: !(
          selectedGame.category === 'logic' ||
          selectedGame.category === 'motion' ||
          selectedGame.completionMethod === 'motion'
        ),
        radius_m: Number(stage.radius_m || stage.proximity_radius_m || stage.radius || 50),
        proximity_radius_m: Number(
          stage.proximity_radius_m || stage.radius_m || stage.radius || 50
        ),
        config: nextConfig,
        title: nextTitle,
        messages: nextMessages,
        content: nextContent,
        description: nextContent,
      })
    }

    onClose()
  }

  function buildQrPatch(game: AdminGameCatalogItem, card?: SavedPhysicalQrCard) {
    const kind = card?.kind || qrKindForGame(game)
    const label = card?.label || qrLabel(stage)
    const itemId = card?.item_id || qrItemId(stage)
    const payload = card?.payload || qrPayload(stage)
    const nextCard: SavedPhysicalQrCard = card || {
      item_id: itemId,
      label,
      kind,
      payload,
      card_text: `${game.icon} ${label}\n${game.title}\nEscanea esta tarjeta en SAGA.`,
      updated_at: new Date().toISOString(),
    }

    const base = getDefaultAdminStagePatchForGame(game.id)
    const nextConfig = {
      ...(base.config || {}),
      ...config,
      game_id: game.id,
      game_title: game.title,
      completion_method: game.completionMethod,
      success_code: fallbackCode(stage),
    }

    return {
      ...base,
      physical_qr: nextCard,
      physical_node_kind: kind,
      physical_item_kind: kind,
      physical_item_id: itemId,
      physical_item_label: label,
      game_family: 'physical_qr',
      game_type: game.id,
      game_template_id: game.id,
      entry_mode: 'qr',
      completion_method: game.completionMethod,
      requires_proximity: false,
      qr_payload: payload,
      fallback_code: fallbackCode(stage),
      physical_fallback_code: fallbackCode(stage),
      config: nextConfig,
      messages: game.messages,
      content: game.content,
      description: game.content,
    }
  }

  function applyMapCollectible() {
    setEditorMode('map_collectible')
    onPatch({
      type: 'signal_hunt',
      label: 'Coleccionable de mapa',
      title: 'Objeto Coleccionable',
      physical_qr: null,
      physical_node_kind: 'collectible',
      physical_item_kind: 'collectible',
      physical_item_id: stage.physical_item_id || qrItemId(stage),
      physical_item_label: stage.physical_item_label || qrLabel(stage),
      game_family: 'physical_qr',
      game_type: 'qr_collectible',
      game_template_id: 'qr_collectible',
      entry_mode: 'gps',
      completion_method: 'proximity',
      requires_proximity: true,
      qr_payload: '',
      fallback_code: 'OK',
      physical_fallback_code: 'OK',
      config: {
        ...config,
        is_map_collectible: true,
        completion_method: 'proximity',
        game_id: 'qr_collectible',
        game_title: 'Objeto de mapa',
      },
      messages: {
        hint: 'Acércate para recoger este objeto.',
        gps_unavailable: 'Activa GPS para poder recoger el objeto.',
        locked: 'Muévete al punto para recoger el objeto.',
      },
      content: 'Un objeto coleccionable se encuentra en esta ubicación. Acércate para recogerlo.',
      description: 'Objeto coleccionable de mapa.',
    })
    goTo('config')
  }

  function applyQr(game: AdminGameCatalogItem) {
    setEditorMode('qr')
    onPatch(buildQrPatch(game))
    goTo('config')
  }

  function saveQrCard() {
    const kind = qrKindForGame(selectedQr)
    const label = qrLabel(stage)
    const itemId = qrItemId(stage)
    const payload = qrPayload(stage)
    const card: SavedPhysicalQrCard = {
      item_id: itemId,
      label,
      kind,
      payload,
      card_text: `${selectedQr.icon} ${label}\n${selectedQr.title}\nEscanea esta tarjeta en SAGA.`,
      updated_at: new Date().toISOString(),
    }
    onPatch(buildQrPatch(selectedQr, card))
    showNotice('QR aplicado al nodo. Pulsa Guardar para persistir.')
  }

  function patchNumber(key: string, value: string) {
    const next = Number(value)
    onPatch({ [key]: Number.isFinite(next) ? next : 0 })
  }

  const configKeys = guidedConfigKeysForGame(mode === 'qr' ? selectedQr : selectedGame, config)

  return (
    <section className="saga-guided-editor-v4" aria-label="Editor guiado de nodo">
      <header className="saga-guided-v4-header">
        <div className="saga-guided-v4-titleblock">
          <span>EDITOR GUIADO</span>
          <h2>{title}</h2>
          <div className="saga-guided-v4-chips">
            <b>
              {mode === 'qr'
                ? `${selectedQr.icon} ${selectedQr.title}`
                : mode === 'map_collectible'
                  ? '⭐ Coleccionable'
                  : `${selectedGame.icon} ${selectedGame.title}`}
            </b>
            <b>
              {mode === 'map_collectible'
                ? 'Jugable'
                : statusLabel(mode === 'qr' ? selectedQr : selectedGame)}
            </b>
            <b>
              {mode === 'map_collectible'
                ? 'Offline listo'
                : offlineLabel(mode === 'qr' ? selectedQr : selectedGame)}
            </b>
            {stage.lat != null && stage.lon != null ? (
              <b>
                {Number(stage.lat).toFixed(5)}, {Number(stage.lon).toFixed(5)}
              </b>
            ) : null}
          </div>
        </div>

        <div className="saga-guided-v4-actions">
          <button
            type="button"
            className="primary-soft"
            onClick={() => {
              if (onRequestChangeType) {
                onRequestChangeType()
              } else {
                onPatch({ _type_choice_done: false })
              }
            }}
          >
            Cambiar tipo
          </button>
          <button type="button" className="danger" onClick={onDelete}>
            Eliminar
          </button>
          <button type="button" onClick={onClose}>
            Cerrar ×
          </button>
        </div>
      </header>

      <nav className="saga-guided-v4-stepper" aria-label="Pasos del editor guiado">
        {STEPS.map((item, index) => (
          <button
            key={item.key}
            type="button"
            className={index === stepIndex ? 'active' : ''}
            onClick={() => setStepIndex(index)}
          >
            <span>{index + 1}</span>
            <b>{item.label}</b>
          </button>
        ))}
      </nav>

      <div className="saga-guided-v4-progress" aria-hidden="true">
        <i style={{ width: `${progress}%` }} />
      </div>

      <main className="saga-guided-v4-body">
        {step === 'subtype' && mode === 'game' ? (
          <section className="saga-guided-v4-page saga-guided-v4-page--catalog">
            <div className="saga-guided-v4-pagehead">
              <span>Paso 2</span>
              <h3>Elige el juego</h3>
              <p>
                Muestra el catálogo real. Los planificados pueden prepararse, pero los más seguros son
                “Jugable”.
              </p>
            </div>

            <div className="saga-guided-v4-toggle-row">
              <span>
                {showExperimentalGames
                  ? 'Mostrando también juegos experimentales/no listos.'
                  : 'Mostrando solo juegos jugables ahora.'}
              </span>
              <button type="button" onClick={() => setShowExperimentalGames((value) => !value)}>
                {showExperimentalGames ? 'Ocultar no listos' : 'Mostrar experimentales'}
              </button>
            </div>

            <div className="saga-guided-v4-catalog-grid">
              {gameOptions(showExperimentalGames).map((game) => (
                <button
                  key={game.id}
                  type="button"
                  className={selectedGame.id === game.id ? 'active' : ''}
                  onClick={() => applyGame(game)}
                >
                  <i>{game.icon}</i>
                  <strong>{game.title}</strong>
                  <small>{game.summary}</small>
                  <em className={isExperimentalOrPlanned(game) ? 'warning' : ''}>
                    {statusLabel(game)} · {offlineLabel(game)} · {game.duration}
                  </em>
                </button>
              ))}
            </div>
          </section>
        ) : null}

        {step === 'subtype' && mode === 'qr' ? (
          <section className="saga-guided-v4-page saga-guided-v4-page--choices">
            <div className="saga-guided-v4-pagehead">
              <span>Paso 1</span>
              <h3>Elige el subtipo de QR físico</h3>
              <p>Selecciona una plantilla de tarjeta física del catálogo SAGA.</p>
            </div>

            <div className="saga-guided-v4-choice-grid">
              {qrOptions().map((game) => (
                <button
                  key={game.id}
                  type="button"
                  className={selectedQr.id === game.id ? 'active' : ''}
                  onClick={() => applyQr(game)}
                >
                  <i>{game.icon}</i>
                  <strong>{game.title}</strong>
                  <small>{game.summary}</small>
                  <em>
                    {statusLabel(game)} · {offlineLabel(game)}
                  </em>
                </button>
              ))}
            </div>
          </section>
        ) : null}

        {step === 'subtype' && mode === 'map_collectible' ? (
          <section className="saga-guided-v4-page">
            <div className="saga-guided-v4-pagehead">
              <span>Paso 1</span>
              <h3>🌟 Coleccionable en mapa</h3>
              <p>Objeto GPS que el jugador recoge al acercarse físicamente al punto.</p>
            </div>

            <div className="saga-guided-v4-formgrid">
              <article className="saga-guided-v4-note wide">
                <b>¿Cómo funciona para el jugador?</b>
                <span>
                  <strong>1️⃣ Se acerca al punto</strong> → Su app detecta que está dentro del radio
                  GPS.
                  <br />
                  <strong>2️⃣ Se abre un panel</strong> → La pantalla muestra el objeto y un botón
                  para recogerlo.
                  <br />
                  <strong>3️⃣ Pulsa OK / Recoger</strong> → El objeto se guarda en su mochila
                  automáticamente.
                  <br />
                  <strong>4️⃣ Lo usa en la Mesa o en un nodo</strong> → Si es ingrediente, puede
                  combinarlo en la Mesa para fabricar algo mayor. Si un nodo lo requiere, ese nodo
                  se desbloquea al llegar con el objeto.
                </span>
              </article>

              <article
                className="saga-guided-v4-note wide"
                style={{
                  borderColor: 'rgba(251,191,36,0.22)',
                  background: 'rgba(251,191,36,0.06)',
                }}
              >
                <b>💡 Diferencia con QR físico</b>
                <span>
                  El coleccionable de mapa <strong>no necesita tarjeta impresa</strong>. Se recoge
                  solo por GPS al pasar cerca. El QR físico sí necesita que el jugador escanee una
                  tarjeta impresa que tú habrás colocado en el lugar.
                </span>
              </article>
            </div>
          </section>
        ) : null}

        {step === 'config' ? (
          <section className="saga-guided-v4-page">
            <div className="saga-guided-v4-pagehead">
              <span>Paso 2</span>
              <h3>
                {mode === 'qr'
                  ? 'Configurar QR físico'
                  : mode === 'map_collectible'
                    ? 'Configurar objeto en mapa'
                    : 'Ajustes del juego'}
              </h3>
              {customGameEditor ? null : (
                <p>
                  {mode === 'map_collectible'
                    ? 'Define el ID y nombre del objeto que el jugador obtendrá.'
                    : (mode === 'qr' ? selectedQr : selectedGame).editorHint}
                </p>
              )}
            </div>

            {mode === 'game' ? (
              <div className="saga-guided-v4-formgrid">
                {!customGameEditor ? (
                  <article className="saga-guided-v4-note wide">
                    <b>{selectedGame.playerGoal}</b>
                    <span>{selectedGame.offlineNote}</span>
                  </article>
                ) : null}

                {usesLocationRadius(selectedGame) ? (
                  <label>
                    <span>Radio visible del nodo</span>
                    <input
                      type="number"
                      value={Number(
                        stage.radius_m || stage.proximity_radius_m || stage.radius || 50
                      )}
                      onChange={(event) => {
                        patchNumber('radius_m', event.target.value)
                        patchNumber('proximity_radius_m', event.target.value)
                        patchNumber('radius', event.target.value)
                      }}
                    />
                  </label>
                ) : null}

                {configKeys.map((key) => {
                  const meta = CONFIG_FIELD_META[key] || {
                    label: key,
                    help: 'Ajuste avanzado oculto normalmente. Revisa solo si sabes qué hace.',
                    type: 'text' as const,
                  }
                  if (key === 'completion_method') return null

                  return (
                    <label key={key} className={key === 'objective' ? 'wide' : ''}>
                      <span>{meta.label}</span>
                      {meta.type === 'select' ? (
                        <select
                          value={
                            key === 'difficulty'
                              ? normalizeDifficultyForEditor(config[key])
                              : formatConfigValue(config[key])
                          }
                          onChange={(event) => patchConfig(key, event.target.value)}
                        >
                          {meta.options?.map((option) => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          type={meta.type === 'number' ? 'number' : 'text'}
                          value={formatConfigValue(config[key])}
                          onChange={(event) => patchConfig(key, event.target.value)}
                        />
                      )}
                      <small>{meta.help}</small>
                    </label>
                  )
                })}

                {selectedGame.id === 'logic_circuit' ? (
                  <div className="wide saga-guided-v4-custom-editor">
                    <CircuitPatternEditor
                      key={selectedGame.id}
                      config={config}
                      onChange={(values) =>
                        onPatch({
                          config: {
                            ...config,
                            ...values,
                          },
                        })
                      }
                    />
                  </div>
                ) : null}

                {selectedGame.id === 'sequence_code' ? (
                  <div className="wide saga-guided-v4-custom-editor">
                    <SequenceCodeEditor
                      key={selectedGame.id}
                      config={config}
                      onChange={(values) =>
                        onPatch({
                          config: {
                            ...config,
                            ...values,
                          },
                        })
                      }
                    />
                  </div>
                ) : null}

                {selectedGame.id === 'tilt_maze' ? (
                  <div className="wide saga-guided-v4-custom-editor">
                    <TiltMazeEditor
                      key={selectedGame.id}
                      config={config}
                      onChange={(values) =>
                        onPatch({
                          config: {
                            ...config,
                            ...values,
                          },
                        })
                      }
                    />
                  </div>
                ) : null}

                {selectedGame.id === 'place_mosaic' ? (
                  <div className="wide saga-guided-v4-custom-editor">
                    <PlaceMosaicEditor
                      key={selectedGame.id}
                      config={config}
                      onChange={(values) =>
                        onPatch({
                          config: {
                            ...config,
                            ...values,
                          },
                        })
                      }
                    />
                  </div>
                ) : null}
              </div>
            ) : mode === 'map_collectible' ? (
              <div className="saga-guided-v4-formgrid">
                <article className="saga-guided-v4-note wide">
                  <b>🌟 Coleccionable en mapa</b>
                  <span>
                    El jugador recoge este objeto cuando pasa cerca del punto. No hace falta
                    escanear un QR. En el mapa de administrador verás líneas que conectan este nodo
                    con otros que lo necesitan.
                  </span>
                </article>

                <label className="wide">
                  <span>🎁 ¿Qué objeto DA este nodo al jugador?</span>
                  <select
                    value={
                      [
                        'placa_base',
                        'cables_cobre',
                        'bateria_litio',
                        'cinta_aislante',
                        'llave_rota',
                      ].includes(stage.physical_item_id || '')
                        ? stage.physical_item_id || 'placa_base'
                        : 'custom'
                    }
                    onChange={(event) => {
                      const val = event.target.value
                      if (val === 'custom') {
                        onPatch({
                          physical_item_id: 'objeto_personalizado',
                          physical_item_label: 'Objeto Personalizado',
                          title: 'Objeto Personalizado',
                        })
                      } else {
                        const labels: Record<string, string> = {
                          placa_base: 'Placa base',
                          cables_cobre: 'Cables de cobre',
                          bateria_litio: 'Batería de litio',
                          cinta_aislante: 'Cinta aislante',
                          llave_rota: 'Llave rota',
                        }
                        onPatch({
                          physical_item_id: val,
                          physical_item_label: labels[val],
                          title: labels[val],
                        })
                      }
                    }}
                  >
                    <option value="placa_base">
                      💾 Placa base → ingrediente para fabricar Dispositivo EMP
                    </option>
                    <option value="cables_cobre">
                      🔌 Cables de cobre → ingrediente para fabricar Dispositivo EMP
                    </option>
                    <option value="bateria_litio">
                      🔋 Batería de litio → ingrediente para fabricar Dispositivo EMP
                    </option>
                    <option value="cinta_aislante">
                      🩹 Cinta aislante → ingrediente para reparar la Llave Maestra
                    </option>
                    <option value="llave_rota">
                      🔑 Llave rota → ingrediente para reparar la Llave Maestra
                    </option>
                    <option value="custom">✏️ Otro objeto (nombre personalizado)</option>
                  </select>
                  <small>
                    Este objeto quedará en la mochila del jugador al recogerlo. El ID interno sirve
                    para que otros nodos lo puedan requerir.
                  </small>
                </label>

                {['placa_base', 'cables_cobre', 'bateria_litio'].includes(
                  stage.physical_item_id || ''
                ) ? (
                  <article className="saga-guided-v4-note warning wide">
                    <b>⚠️ ¡Atención! Ingrediente incompleto</b>
                    <span>
                      Has configurado un ingrediente para el <strong>Dispositivo EMP</strong>. El
                      jugador NO podrá usar este objeto directamente. Para que pueda fabricar el
                      dispositivo final en su Mesa de Trabajo,{' '}
                      <strong>debes añadir a la misión otros nodos</strong> que entreguen el resto
                      de ingredientes (Placa base, Cables y Batería). El sistema te bloqueará el
                      guardado si olvidas alguno.
                    </span>
                  </article>
                ) : null}

                {['cinta_aislante', 'llave_rota'].includes(stage.physical_item_id || '') ? (
                  <article className="saga-guided-v4-note warning wide">
                    <b>⚠️ ¡Atención! Ingrediente incompleto</b>
                    <span>
                      Has configurado un ingrediente para la <strong>Llave Maestra</strong>. El
                      jugador NO podrá usar este objeto directamente. Para que pueda fabricarla en
                      su Mesa de Trabajo, <strong>debes añadir a la misión otro nodo</strong> que
                      entregue el ingrediente restante. El sistema te bloqueará el guardado si lo
                      olvidas.
                    </span>
                  </article>
                ) : null}

                {![
                  'placa_base',
                  'cables_cobre',
                  'bateria_litio',
                  'cinta_aislante',
                  'llave_rota',
                ].includes(stage.physical_item_id || '') ? (
                  <>
                    <label>
                      <span>Nombre visible del objeto</span>
                      <input
                        value={qrLabel(stage)}
                        onChange={(event) =>
                          onPatch({
                            physical_item_label: event.target.value,
                            title: event.target.value,
                          })
                        }
                        placeholder="Ej: Tarjeta magnética, Fragmento de mapa..."
                      />
                    </label>

                    <label>
                      <span>ID interno del objeto (para dependencias)</span>
                      <input
                        value={qrItemId(stage)}
                        onChange={(event) =>
                          onPatch({ physical_item_id: slugOf(event.target.value) })
                        }
                        placeholder="ej: tarjeta_magnetica"
                      />
                      <small>
                        Este ID es el que pondrás en otro nodo si ese nodo debe requerir este objeto
                        para poder jugarse.
                      </small>
                    </label>
                  </>
                ) : null}

                <div className="saga-guided-v4-dep-box wide">
                  <div className="saga-guided-v4-dep-box__title">
                    🔒 ¿Este nodo requiere algo para poder recogerse?
                  </div>
                  <p className="saga-guided-v4-dep-box__desc">
                    Opcional. Si lo configuras, el jugador necesitará tener ese objeto en su mochila
                    antes de poder recoger este coleccionable. Aparecerá una línea de conexión en el
                    mapa del administrador.
                  </p>
                  <select
                    value={
                      !stage.required_item_id
                        ? 'none'
                        : ['llave_maestra', 'emp_device'].includes(stage.required_item_id)
                          ? stage.required_item_id
                          : 'custom'
                    }
                    onChange={(event) => {
                      const val = event.target.value
                      if (val === 'none') {
                        onPatch({ required_item_id: '', requires_item: false })
                      } else if (val === 'custom') {
                        onPatch({ required_item_id: 'item_requerido', requires_item: true })
                      } else {
                        onPatch({ required_item_id: val, requires_item: true })
                      }
                    }}
                  >
                    <option value="none">🟢 Libre: cualquier jugador puede recogerlo</option>
                    <option value="llave_maestra">
                      🔑 Requiere Llave Maestra (objeto fabricable)
                    </option>
                    <option value="emp_device">
                      ⚡ Requiere Dispositivo EMP (objeto fabricable)
                    </option>
                    <option value="custom">✏️ Requiere otro objeto (ID personalizado)</option>
                  </select>

                  {stage.required_item_id &&
                  !['llave_maestra', 'emp_device'].includes(stage.required_item_id) ? (
                    <label>
                      <span>ID del objeto que se necesita tener</span>
                      <input
                        value={stage.required_item_id}
                        onChange={(event) =>
                          onPatch({
                            required_item_id: slugOf(event.target.value),
                            requires_item: true,
                          })
                        }
                        placeholder="ej: llave_del_cofre"
                      />
                    </label>
                  ) : null}
                </div>

                <label>
                  <span>Radio de recolección (metros)</span>
                  <input
                    type="number"
                    value={Number(stage.radius_m || stage.proximity_radius_m || stage.radius || 30)}
                    onChange={(event) => {
                      patchNumber('radius_m', event.target.value)
                      patchNumber('proximity_radius_m', event.target.value)
                      patchNumber('radius', event.target.value)
                    }}
                  />
                  <small>
                    El jugador debe estar a menos de este número de metros del punto GPS para
                    recoger el objeto.
                  </small>
                </label>
              </div>
            ) : (
              <div className="saga-guided-v4-formgrid">
                <article className="saga-guided-v4-note wide">
                  <b>{selectedQr.playerGoal}</b>
                  <span>{selectedQr.offlineNote}</span>
                </article>

                <label>
                  <span>Nombre visible</span>
                  <input
                    value={qrLabel(stage)}
                    onChange={(event) =>
                      onPatch({
                        physical_item_label: event.target.value,
                        title: event.target.value,
                      })
                    }
                  />
                </label>

                <label>
                  <span>ID interno</span>
                  <input
                    value={qrItemId(stage)}
                    onChange={(event) => onPatch({ physical_item_id: slugOf(event.target.value) })}
                  />
                </label>

                {['placa_base', 'cables_cobre', 'bateria_litio'].includes(
                  stage.physical_item_id || ''
                ) ? (
                  <article className="saga-guided-v4-note warning wide">
                    <b>⚠️ ¡Atención! Ingrediente incompleto</b>
                    <span>
                      Has escrito un ID de ingrediente para el <strong>Dispositivo EMP</strong>.
                      Para que el jugador pueda fabricarlo en su Mesa de Trabajo, asegúrate de
                      añadir a la misión otros nodos que entreguen el resto de ingredientes.
                    </span>
                  </article>
                ) : null}

                {['cinta_aislante', 'llave_rota'].includes(stage.physical_item_id || '') ? (
                  <article className="saga-guided-v4-note warning wide">
                    <b>⚠️ ¡Atención! Ingrediente incompleto</b>
                    <span>
                      Has escrito un ID de ingrediente para la <strong>Llave Maestra</strong>. Para
                      que el jugador pueda fabricarla en su Mesa de Trabajo, asegúrate de añadir a
                      la misión otro nodo que entregue el ingrediente restante.
                    </span>
                  </article>
                ) : null}

                <label>
                  <span>Código fallback</span>
                  <input
                    value={fallbackCode(stage)}
                    onChange={(event) => {
                      onPatch({
                        fallback_code: event.target.value,
                        physical_fallback_code: event.target.value,
                        config: { ...config, success_code: event.target.value },
                      })
                    }}
                  />
                </label>

                <label>
                  <span>Payload QR</span>
                  <input
                    value={qrPayload(stage)}
                    onChange={(event) =>
                      onPatch({
                        qr_payload: event.target.value,
                        config: {
                          ...config,
                          qr_validation_signature: '',
                          qr_validated_at: '',
                        },
                      })
                    }
                  />
                </label>
              </div>
            )}
          </section>
        ) : null}

        {step === 'content' ? (
          <section className="saga-guided-v4-page">
            <div className="saga-guided-v4-pagehead">
              <span>Paso 3</span>
              <h3>{mode === 'qr' ? 'QR imprimible' : 'Textos y mensajes'}</h3>
              <p>
                {mode === 'qr'
                  ? 'Vista previa y descarga de la tarjeta física.'
                  : 'Lo que ve el jugador durante la misión.'}
              </p>
            </div>

            {mode === 'qr' ? (
              <QrCardStudio
                payload={qrPayload(stage)}
                label={qrLabel(stage)}
                itemId={qrItemId(stage)}
                typeLabel={selectedQr.title}
                design={qrDesign}
                validationSignature={String(config.qr_validation_signature || '')}
                onDesignChange={(design) =>
                  onPatch({
                    config: {
                      ...config,
                      qr_card_preset: design.preset,
                      qr_card_shape: design.shape,
                      qr_card_accent: design.accent,
                      qr_card_image_data_url: design.imageDataUrl,
                      qr_validation_signature: '',
                      qr_validated_at: '',
                    },
                  })
                }
                onValidated={(signature) =>
                  onPatch({
                    config: {
                      ...config,
                      qr_validation_signature: signature,
                      qr_validated_at: new Date().toISOString(),
                    },
                  })
                }
                onApply={saveQrCard}
              />
            ) : (
              <div className="saga-guided-v4-formgrid">
                <label>
                  <span>Título</span>
                  <input
                    value={String(stage.title || '')}
                    onChange={(event) => onPatch({ title: event.target.value })}
                  />
                </label>

                <label className="wide">
                  <span>Texto principal</span>
                  <textarea
                    value={String(
                      stage.content || stage.description || stage.body || selectedGame.content || ''
                    )}
                    onChange={(event) =>
                      onPatch({
                        content: event.target.value,
                        description: event.target.value,
                        body: event.target.value,
                      })
                    }
                    placeholder={selectedGame.content}
                  />
                </label>

                <label>
                  <span>Pista</span>
                  <textarea
                    value={normalizeMessage(stage.messages?.hint, selectedGame.messages.hint)}
                    onChange={(event) =>
                      onPatch({ messages: { ...(stage.messages || {}), hint: event.target.value } })
                    }
                    placeholder={selectedGame.messages.hint}
                  />
                </label>

                <label>
                  <span>Sin GPS / sensor</span>
                  <textarea
                    value={normalizeMessage(
                      stage.messages?.gps_unavailable,
                      selectedGame.messages.gps_unavailable
                    )}
                    onChange={(event) =>
                      onPatch({
                        messages: {
                          ...(stage.messages || {}),
                          gps_unavailable: event.target.value,
                        },
                      })
                    }
                    placeholder={selectedGame.messages.gps_unavailable}
                  />
                </label>

                <label>
                  <span>Bloqueado / no completado</span>
                  <textarea
                    value={normalizeMessage(stage.messages?.locked, selectedGame.messages.locked)}
                    onChange={(event) =>
                      onPatch({
                        messages: { ...(stage.messages || {}), locked: event.target.value },
                      })
                    }
                    placeholder={selectedGame.messages.locked}
                  />
                </label>

                <label>
                  <span>Al completar</span>
                  <textarea
                    value={String(
                      stage.success_message || 'Ben feito. Desbloqueaches a seguinte pista.'
                    )}
                    onChange={(event) => onPatch({ success_message: event.target.value })}
                    placeholder="Ben feito. Desbloqueaches a seguinte pista."
                  />
                </label>
              </div>
            )}
          </section>
        ) : null}

        {step === 'rules' ? (
          <section className="saga-guided-v4-page">
            <div className="saga-guided-v4-pagehead">
              <span>Paso 4</span>
              <h3>🔒 Desbloqueos y requisitos</h3>
              <p>
                ¿Este nodo necesita que el jugador tenga algún objeto antes de poder jugarlo? Aquí
                se configura y se crean las líneas de conexión visibles en el mapa de admin.
              </p>
            </div>

            <div className="saga-guided-v4-formgrid">
              <div className="saga-guided-v4-dep-box wide">
                <div className="saga-guided-v4-dep-box__title">
                  🔑 Objeto requerido para jugar este nodo
                </div>
                <p className="saga-guided-v4-dep-box__desc">
                  Si lo dejas en «Ninguno», el jugador puede llegar a este nodo en cualquier momento
                  según el orden de ruta.
                  <br />
                  <br />
                  Si seleccionas un objeto, el jugador{' '}
                  <strong>necesita tenerlo en la mochila</strong> antes de que este nodo se
                  desbloquee. En el mapa del administrador aparecerá una{' '}
                  <strong>línea de color</strong> conectando el nodo que da ese objeto con este
                  nodo.
                  <br />
                  <br />
                  💡{' '}
                  <em>
                    Para que la línea aparezca en el mapa, el ID de este campo debe coincidir
                    exactamente con el ID interno del objeto que genera otro nodo.
                  </em>
                </p>

                <label>
                  <span>¿Requiere algún objeto?</span>
                  <select
                    value={String(stage.required_item_id || '') ? 'item' : 'none'}
                    onChange={(event) => {
                      if (event.target.value === 'none')
                        onPatch({ required_item_id: '', requires_item: false })
                      else onPatch({ requires_item: true })
                    }}
                  >
                    <option value="none">🟢 No requiere nada — juego libre</option>
                    <option value="item">
                      🔑 Sí — requiere un objeto específico en la mochila
                    </option>
                  </select>
                </label>

                {String(stage.required_item_id || '') || stage.requires_item ? (
                  <label>
                    <span>ID del objeto requerido</span>
                    <input
                      value={String(stage.required_item_id || '')}
                      onChange={(event) =>
                        onPatch({
                          required_item_id: event.target.value,
                          requires_item: Boolean(event.target.value),
                        })
                      }
                      placeholder="Ej: llave_maestra, emp_device, tarjeta_magnetica..."
                    />
                    <small>
                      Debe coincidir exactamente con el ID interno del objeto que da otro nodo
                      (coleccionable o QR).
                    </small>
                  </label>
                ) : null}

                <label className="checkbox">
                  <input
                    checked={Boolean(stage.consume_required_item)}
                    type="checkbox"
                    onChange={(event) => onPatch({ consume_required_item: event.target.checked })}
                  />
                  <span>Consumir objeto al superar el nodo (se retira de la mochila)</span>
                </label>
              </div>

              {/* RECOMPENSAS AL COMPLETAR */}
              <div
                className="saga-guided-v4-dep-box wide"
                style={{ borderLeft: '3px solid #10b981', background: 'rgba(16,185,129,0.04)' }}
              >
                <div className="saga-guided-v4-dep-box__title" style={{ color: '#10b981' }}>
                  🎁 Recompensa al completar (opcional)
                </div>
                <p className="saga-guided-v4-dep-box__desc">
                  ¿Quieres que este juego entregue algún objeto coleccionable al jugador cuando lo
                  resuelva con éxito?
                </p>

                <label>
                  <span>¿Entrega algún objeto?</span>
                  <select
                    value={
                      [
                        'placa_base',
                        'cables_cobre',
                        'bateria_litio',
                        'cinta_aislante',
                        'llave_rota',
                      ].includes(stage.config?.reward_item_id || '')
                        ? stage.config?.reward_item_id || 'placa_base'
                        : stage.config?.reward_item_id
                          ? 'custom'
                          : 'none'
                    }
                    onChange={(event) => {
                      const val = event.target.value
                      if (val === 'none') {
                        onPatch({
                          config: {
                            ...config,
                            reward_item_id: '',
                            reward_item_label: '',
                            reward_message: '',
                          },
                        })
                      } else if (val === 'custom') {
                        onPatch({
                          config: {
                            ...config,
                            reward_item_id: 'objeto_recompensa',
                            reward_item_label: 'Objeto Recompensa',
                            reward_message: '¡Has recibido un objeto!',
                          },
                        })
                      } else {
                        const labels: Record<string, string> = {
                          placa_base: 'Placa base',
                          cables_cobre: 'Cables de cobre',
                          bateria_litio: 'Batería de litio',
                          cinta_aislante: 'Cinta aislante',
                          llave_rota: 'Llave rota',
                        }
                        onPatch({
                          config: {
                            ...config,
                            reward_item_id: val,
                            reward_item_label: labels[val],
                            reward_message: `¡Has recibido: ${labels[val]}!`,
                          },
                        })
                      }
                    }}
                  >
                    <option value="none">🟢 Ninguno — no entrega objetos</option>
                    <option value="placa_base">💾 Placa base (ingrediente EMP)</option>
                    <option value="cables_cobre">🔌 Cables de cobre (ingrediente EMP)</option>
                    <option value="bateria_litio">🔋 Batería de litio (ingrediente EMP)</option>
                    <option value="cinta_aislante">
                      🩹 Cinta aislante (ingrediente Llave Maestra)
                    </option>
                    <option value="llave_rota">🔑 Llave rota (ingrediente Llave Maestra)</option>
                    <option value="custom">✏️ Otro objeto (ID personalizado)</option>
                  </select>
                </label>

                {['placa_base', 'cables_cobre', 'bateria_litio'].includes(
                  stage.config?.reward_item_id || ''
                ) ? (
                  <article className="saga-guided-v4-note warning wide">
                    <b>⚠️ ¡Atención! Ingrediente incompleto</b>
                    <span>
                      Has seleccionado un ingrediente para el <strong>Dispositivo EMP</strong> como
                      recompensa. Para que el jugador pueda fabricarlo en su Mesa de Trabajo,
                      asegúrate de añadir a la misión otros nodos que entreguen el resto de
                      ingredientes.
                    </span>
                  </article>
                ) : null}

                {['cinta_aislante', 'llave_rota'].includes(stage.config?.reward_item_id || '') ? (
                  <article className="saga-guided-v4-note warning wide">
                    <b>⚠️ ¡Atención! Ingrediente incompleto</b>
                    <span>
                      Has seleccionado un ingrediente para la <strong>Llave Maestra</strong> como
                      recompensa. Para que el jugador pueda fabricarla en su Mesa de Trabajo,
                      asegúrate de añadir a la misión otro nodo que entregue el ingrediente
                      restante.
                    </span>
                  </article>
                ) : null}

                {stage.config?.reward_item_id &&
                ![
                  'placa_base',
                  'cables_cobre',
                  'bateria_litio',
                  'cinta_aislante',
                  'llave_rota',
                ].includes(stage.config?.reward_item_id) ? (
                  <>
                    <label>
                      <span>Nombre del objeto de recompensa</span>
                      <input
                        value={String(stage.config?.reward_item_label || '')}
                        onChange={(event) =>
                          onPatch({
                            config: {
                              ...config,
                              reward_item_label: event.target.value,
                            },
                          })
                        }
                        placeholder="Ej: Llave dorada"
                      />
                    </label>
                    <label>
                      <span>ID interno del objeto de recompensa</span>
                      <input
                        value={String(stage.config?.reward_item_id || '')}
                        onChange={(event) =>
                          onPatch({
                            config: {
                              ...config,
                              reward_item_id: event.target.value
                                .toLowerCase()
                                .replace(/[^a-z0-9]+/g, '_'),
                            },
                          })
                        }
                        placeholder="ej: llave_dorada"
                      />
                    </label>
                  </>
                ) : null}

                {stage.config?.reward_item_id ? (
                  <label>
                    <span>Mensaje de recompensa</span>
                    <input
                      value={String(stage.config?.reward_message || '')}
                      onChange={(event) =>
                        onPatch({
                          config: {
                            ...config,
                            reward_message: event.target.value,
                          },
                        })
                      }
                      placeholder="¡Has obtenido un nuevo objeto para tu mochila!"
                    />
                  </label>
                ) : null}
              </div>

              <label>
                <span>🆘 Código de emergencia (fallback)</span>
                <input
                  value={fallbackCode(stage)}
                  onChange={(event) =>
                    onPatch({
                      fallback_code: event.target.value,
                      config: { ...config, success_code: event.target.value },
                    })
                  }
                />
                <small>
                  Si el jugador tiene problemas con la app o GPS, puede introducir este código
                  manualmente para completar el nodo.
                </small>
              </label>

              <article className="saga-guided-v4-note wide">
                <b>💡 Sobre las líneas en el mapa</b>
                <span>
                  Línea <strong style={{ color: '#38bdf8' }}>azul celeste</strong>: conexión directa
                  (el nodo A da el objeto que requiere el nodo B).
                  <br />
                  Línea <strong style={{ color: '#a78bfa' }}>violeta</strong>: el objeto es un
                  ingrediente de una receta de fabricación.
                </span>
              </article>
            </div>
          </section>
        ) : null}

        {step === 'review' ? (
          <section className="saga-guided-v4-page">
            <div className="saga-guided-v4-pagehead">
              <span>Paso 5</span>
              <h3>Revisar nodo</h3>
              <p>Resumen antes de cerrar. Recuerda Guardar en Builder para persistir.</p>
            </div>

            <div className="saga-guided-v4-review">
              <article>
                <b>Tipo</b>
                <span>{mode === 'qr' ? 'QR físico' : mode === 'map_collectible' ? 'Coleccionable en mapa' : 'Nodo de juego'}</span>
              </article>
              <article>
                <b>Modo</b>
                <span>{mode === 'qr' ? selectedQr.title : mode === 'map_collectible' ? 'Objeto de mapa' : selectedGame.title}</span>
              </article>
              <article>
                <b>Estado</b>
                <span>{mode === 'map_collectible' ? 'Jugable' : statusLabel(mode === 'qr' ? selectedQr : selectedGame)}</span>
              </article>
              <article>
                <b>Offline</b>
                <span>{mode === 'map_collectible' ? 'Offline listo' : offlineLabel(mode === 'qr' ? selectedQr : selectedGame)}</span>
              </article>
              <article>
                <b>Completa por</b>
                <span>
                  {mode === 'map_collectible' ? 'proximity' : String(
                    config.completion_method ||
                      (mode === 'qr' ? selectedQr.completionMethod : selectedGame.completionMethod)
                  )}
                </span>
              </article>
              <article>
                <b>Fallback</b>
                <span>{fallbackCode(stage)}</span>
              </article>
              {mode === 'qr' ? (
                <article>
                  <b>Validación QR</b>
                  <span>{qrValidated ? 'Validado para este diseño' : 'Pendiente de validar'}</span>
                </article>
              ) : null}
            </div>
          </section>
        ) : null}
      </main>

      <footer className="saga-guided-v4-footer">
        <button type="button" onClick={goBack} disabled={stepIndex === 0}>
          Atrás
        </button>
        <button
          type="button"
          className="secondary"
          onClick={() => {
            if (onRequestChangeType) {
              onRequestChangeType()
            } else {
              onPatch({ _type_choice_done: false })
            }
          }}
        >
          Cambiar tipo
        </button>
        {stepIndex < STEPS.length - 1 ? (
          <button type="button" className="primary" onClick={goNext}>
            Siguiente
          </button>
        ) : (
          <button type="button" className="primary" onClick={finalizeAndClose}>
            Listo
          </button>
        )}
      </footer>
    </section>
  )
}
