// eslint-disable-next-line @typescript-eslint/no-unused-vars
import type { AdminReactOverviewStage as _AdminReactOverviewStage } from './adminApi'
import {
  getAdminFamilyIcon,
  getAdminFamilyLabel,
  getDefaultAdminConfigForFamily,
  type FamilyId,
} from './familyConfigs'

export type AdminGameId =
  | 'simple_checkpoint'
  | 'shake_antenna_charge'
  | 'gps_signal_lock'
  | 'hot_cold_search'
  | 'bearing_compass'
  | 'three_bearing_triangle'
  | 'logic_circuit'
  | 'sequence_code'
  | 'place_mosaic'
  | 'tilt_maze'
  | 'qr_collectible'
  | 'qr_key_gate'
  | 'clue_card'
  | 'photo_scout'
  | 'team_relay'
  | 'manual_password'
  | 'bonus_cache'
  | 'audio_challenge'

export type AdminGameRuntimeStatus = 'runtime_ready' | 'runtime_partial' | 'preset_only' | 'planned'
export type AdminGameOfflineStatus = 'offline_ready' | 'offline_partial' | 'offline_planned'
export type AdminGameCompletionMethod =
  | 'proximity'
  | 'hold'
  | 'bearing'
  | 'puzzle'
  | 'manual_code'
  | 'sequence'
  | 'qr_complete'
  | 'photo'
  | 'inventory_only'
  | 'team'
  | 'motion'

export type MissionTemplateId = 'qr_route' | 'clue_hunt' | 'urban_escape' | 'family_gymkhana'

export type AdminGameCatalogItem = {
  id: AdminGameId
  title: string
  icon: string
  family: FamilyId
  category: 'gps' | 'compass' | 'logic' | 'physical' | 'photo' | 'team' | 'motion'
  difficulty: 'Fácil' | 'Media' | 'Alta'
  duration: string
  runtimeStatus: AdminGameRuntimeStatus
  offlineStatus: AdminGameOfflineStatus
  completionMethod: AdminGameCompletionMethod
  offlineNote: string
  summary: string
  playerGoal: string
  editorHint: string
  config: Record<string, unknown>
  content: string
  messages: {
    hint: string
    gps_unavailable: string
    locked: string
  }
}

export type MissionTemplateStage = {
  gameId: AdminGameId
  title: string
  content: string
  radius?: number
  offsetLat: number
  offsetLon: number
  physicalKind?: 'collectible' | 'requirement' | 'clue' | 'bonus'
  itemLabel?: string
  requiresPreviousItem?: boolean
}

export type MissionTemplate = {
  id: MissionTemplateId
  title: string
  icon: string
  summary: string
  goodFor: string
  stages: MissionTemplateStage[]
}

export const adminGameCatalog: AdminGameCatalogItem[] = [
  {
    id: 'simple_checkpoint',
    title: 'Checkpoint / Texto Rápido',
    icon: '📍',
    family: 'signal_hunt',
    category: 'gps',
    difficulty: 'Fácil',
    duration: '1 min',
    runtimeStatus: 'runtime_ready',
    offlineStatus: 'offline_ready',
    completionMethod: 'proximity',
    offlineNote: 'Solo requiere llegar a las coordenadas GPS.',
    summary: 'Nodo básico de control. El jugador llega al punto y lee el texto o pista.',
    playerGoal: 'Llega al punto de control para avanzar en la ruta.',
    editorHint: 'Ideal para inicio de ruta, puntos intermedios y revelación de historia.',
    config: {
      game_id: 'simple_checkpoint',
      objective: 'checkpoint',
      completion_method: 'proximity',
    },
    content: 'Punto de control alcanzado. Lee la información antes de continuar.',
    messages: {
      hint: 'Revisa las coordenadas en el mapa.',
      gps_unavailable: 'Sin cobertura GPS.',
      locked: 'Acércate al punto para continuar.',
    },
  },
  {
    id: 'logic_circuit',
    title: 'Matriz de circuitos',
    icon: '🧩',
    family: 'circuit_matrix',
    category: 'logic',
    difficulty: 'Media',
    duration: '4-7 min',
    runtimeStatus: 'runtime_ready',
    offlineStatus: 'offline_ready',
    completionMethod: 'puzzle',
    offlineNote: 'Funciona completamente en local y sincroniza el resultado después.',
    summary: 'Juego táctil de reparar una ruta de energía en una matriz.',
    playerGoal: 'Memorizar una ruta y repetirla en el orden exacto.',
    editorHint: 'Úsalo cuando quieras un descanso mental entre puntos GPS.',
    config: {
      objective: 'path_restore',
      completion_method: 'puzzle',
      grid_cols: 5,
      grid_rows: 5,
      difficulty: 'normal',
      max_errors: 3,
      preview_cell_ms: 460,
      path_length: 11,
      seed: '',
      pattern_mode: 'random_each_game',
      path_cells: [],
      game_id: 'logic_circuit',
    },
    content: 'Memoriza la ruta de energía y repítela en el mismo orden.',
    messages: {
      hint: 'Memoriza la secuencia. Después repítela sin guía.',
      gps_unavailable: 'Este reto puede jugarse sin GPS si el nodo ya está abierto.',
      locked: 'Completa el circuito para continuar.',
    },
  },
  {
    id: 'sequence_code',
    title: 'Código secuencial',
    icon: '🔢',
    family: 'circuit_matrix',
    category: 'logic',
    difficulty: 'Media',
    duration: '2-5 min',
    runtimeStatus: 'runtime_ready',
    offlineStatus: 'offline_ready',
    completionMethod: 'sequence',
    offlineNote: 'Funciona completamente en local y sincroniza el resultado al recuperar conexión.',
    summary:
      'Deducir el orden oculto usando un tríptico, mapa, historia o conjunto de pistas físicas.',
    playerGoal: 'Consultar el material de misión y reconstruir el orden exacto de las pistas.',
    editorHint:
      'Escribe de tres a diez elementos en el orden correcto. El jugador deberá deducirlo usando su tríptico o material físico.',
    config: {
      objective: 'sequence_order',
      game_id: 'sequence_code',
      completion_method: 'sequence',
      sequence: ['ROBLE', 'CAMPANA', 'PUENTE', 'TORRE'],
      difficulty: 'normal',
      max_attempts: 3,
      hint_text: 'Busca qué sucede antes de cruzar el puente y cuál es el último destino.',
      shuffle_choices: true,
    },
    content: 'Consulta tu tríptico y pulsa las fichas en el orden que revelan las pistas.',
    messages: {
      hint: 'Busca qué sucede antes, después y al final de la historia.',
      gps_unavailable: 'Este reto funciona sin GPS cuando el nodo está abierto.',
      locked: 'El orden todavía no coincide con las pistas del tríptico.',
    },
  },
  {
    id: 'place_mosaic',
    title: 'Mosaico del lugar',
    icon: '🖼️',
    family: 'circuit_matrix',
    category: 'photo',
    difficulty: 'Media',
    duration: '3-8 min',
    runtimeStatus: 'runtime_ready',
    offlineStatus: 'offline_ready',
    completionMethod: 'puzzle',
    offlineNote:
      'La fotografía viaja dentro de la misión y el puzle funciona completamente sin conexión.',
    summary: 'Reconstruir una fotografía del lugar real intercambiando sus piezas.',
    playerGoal: 'Observar el entorno, ordenar el mosaico y reconocer un detalle del punto real.',
    editorHint:
      'Sube una fotografía clara del molino, estatua, edificio, piedra o detalle que el jugador tendrá delante.',
    config: {
      objective: 'image_mosaic',
      game_id: 'place_mosaic',
      completion_method: 'puzzle',
      image_data_url: '',
      image_alt: '',
      grid_size: 3,
      grid_cols: 3,
      grid_rows: 3,
      preview_ms: 2500,
      max_moves: 0,
      require_final_question: false,
      final_question: '¿Qué detalle aparece en el lugar real?',
      final_choices: ['Puerta', 'Escudo', 'Campana'],
      final_correct_index: 0,
    },
    content: 'Reconstruye la fotografía observando el lugar real.',
    messages: {
      hint: 'Compara formas, colores y detalles con el elemento que tienes delante.',
      gps_unavailable: 'Este reto puede jugarse sin GPS cuando el nodo ya está abierto.',
      locked: 'Completa el mosaico para continuar.',
    },
  },
  {
    id: 'tilt_maze',
    title: 'Laberinto de equilibrio',
    icon: '🎱',
    family: 'circuit_matrix',
    category: 'motion',
    difficulty: 'Media',
    duration: '2-6 min',
    runtimeStatus: 'runtime_ready',
    offlineStatus: 'offline_ready',
    completionMethod: 'motion',
    offlineNote:
      'El laberinto, los controles táctiles y el sensor funcionan completamente sin conexión.',
    summary: 'Guiar una bola por un laberinto generado automáticamente inclinando el móvil.',
    playerGoal: 'Recoger los objetos, evitar los agujeros y alcanzar la salida.',
    editorHint:
      'Elige tamaño y dificultad. Puedes fijar un laberinto o generar uno nuevo en cada partida.',
    config: {
      objective: 'balance_maze',
      game_id: 'tilt_maze',
      completion_method: 'motion',
      difficulty: 'normal',
      grid_rows: 9,
      grid_cols: 9,
      pattern_mode: 'fixed',
      maze_seed: 'saga-maze',
      time_limit_s: 75,
      lives: 3,
      hole_count: 4,
      collectible_count: 2,
      sensor_enabled: true,
      tilt_threshold: 12,
      step_cooldown_ms: 360,
    },
    content: 'Inclina el móvil o usa los botones para guiar la bola hasta la salida.',
    messages: {
      hint: 'Muévete despacio, recoge los objetos y evita los agujeros.',
      gps_unavailable: 'Este reto funciona sin GPS cuando el nodo está abierto.',
      locked: 'Supera el laberinto para continuar.',
    },
  },
  {
    id: 'qr_collectible',
    title: 'Objeto QR',
    icon: '⭐',
    family: 'signal_hunt',
    category: 'physical',
    difficulty: 'Fácil',
    duration: '1-2 min',
    runtimeStatus: 'runtime_ready',
    offlineStatus: 'offline_ready',
    completionMethod: 'inventory_only',
    offlineNote:
      'Crea tarjeta QR en admin, se exporta, el player la lee offline y guarda el objeto en mochila local.',
    summary: 'Tarjeta física opcional que se guarda en la mochila.',
    playerGoal: 'Escanear una tarjeta QR y conservar el objeto.',
    editorHint: 'Úsalo para coleccionables, logros o pistas secundarias.',
    config: {
      objective: 'physical_collectible',
      completion_method: 'inventory_only',
      game_id: 'qr_collectible',
    },
    content: 'Encuentra y escanea la tarjeta QR física.',
    messages: {
      hint: 'Busca una tarjeta o símbolo físico cerca.',
      gps_unavailable: 'Acércate al punto para escanear el QR.',
      locked: 'Necesitas estar en la zona del QR.',
    },
  },
  {
    id: 'qr_key_gate',
    title: 'Llave QR',
    icon: '🔑',
    family: 'signal_hunt',
    category: 'physical',
    difficulty: 'Fácil',
    duration: '1-3 min',
    runtimeStatus: 'runtime_ready',
    offlineStatus: 'offline_ready',
    completionMethod: 'inventory_only',
    offlineNote:
      'Crea llave QR en admin, se exporta, el player la lee offline y guarda la llave para requisitos.',
    summary: 'Objeto QR pensado para abrir otro nodo posterior.',
    playerGoal: 'Conseguir una llave física para desbloquear una prueba.',
    editorHint: 'Úsalo junto con Requisito de entrada en un nodo posterior.',
    config: {
      objective: 'physical_key',
      completion_method: 'inventory_only',
      game_id: 'qr_key_gate',
    },
    content: 'Escanea la llave QR. Podría hacer falta más adelante.',
    messages: {
      hint: 'Busca la llave física.',
      gps_unavailable: 'Activa GPS o usa el modo permitido para abrir el QR.',
      locked: 'Acércate para registrar la llave.',
    },
  },
  {
    id: 'clue_card',
    title: 'Pista QR',
    icon: '🧩',
    family: 'signal_hunt',
    category: 'physical',
    difficulty: 'Fácil',
    duration: '1-2 min',
    runtimeStatus: 'runtime_ready',
    offlineStatus: 'offline_ready',
    completionMethod: 'inventory_only',
    offlineNote:
      'Crea pista QR en admin, se exporta, el player la lee offline y guarda la pista consultable en mochila.',
    summary: 'Tarjeta que entrega información para resolver otro reto.',
    playerGoal: 'Escanear una pista y leer la información.',
    editorHint: 'Ideal para rutas de misterio o escape.',
    config: {
      objective: 'physical_clue',
      completion_method: 'inventory_only',
      game_id: 'clue_card',
    },
    content: 'Escanea la pista y úsala en un nodo posterior.',
    messages: {
      hint: 'La pista no está lejos del punto.',
      gps_unavailable: 'Necesitas abrir el nodo para escanear la pista.',
      locked: 'Acércate para consultar la pista.',
    },
  },
  {
    id: 'photo_scout',
    title: 'Foto de exploración',
    icon: '📷',
    family: 'signal_hunt',
    category: 'photo',
    difficulty: 'Fácil',
    duration: '2-4 min',
    runtimeStatus: 'planned',
    offlineStatus: 'offline_planned',
    completionMethod: 'photo',
    offlineNote:
      'No se ofrece en plantillas jugables todavía: falta completar el flujo de cierre por foto.',
    summary: 'El equipo debe hacer una foto de campo en la zona.',
    playerGoal: 'Capturar una foto compartida en el mapa.',
    editorHint: 'Funciona muy bien con el sistema de fotos de campo.',
    config: { objective: 'photo_proof', completion_method: 'photo', game_id: 'photo_scout' },
    content: 'Haz una foto de campo que demuestre que encontraste la zona.',
    messages: {
      hint: 'Busca un elemento reconocible del entorno.',
      gps_unavailable: 'Necesitas ubicación para anclar la foto al mapa.',
      locked: 'Acércate antes de hacer la foto.',
    },
  },
  {
    id: 'team_relay',
    title: 'Relevo de equipo',
    icon: '👥',
    family: 'signal_hunt',
    category: 'team',
    difficulty: 'Media',
    duration: '5-8 min',
    runtimeStatus: 'runtime_ready',
    offlineStatus: 'offline_ready',
    completionMethod: 'team',
    offlineNote:
      'Funciona offline. Si hay conexión usa Yjs para ver a los compañeros, si no, se cierra cuando todos registran el nodo.',
    summary: 'Prueba pensada para varios jugadores o roles.',
    playerGoal: 'Coordinarse para llegar, registrar prueba o compartir pista.',
    editorHint: 'Úsalo si quieres que varios jugadores participen.',
    config: {
      objective: 'team_relay',
      source_radius_m: 80,
      lock_threshold: 60,
      hold_ms: 1500,
      game_id: 'team_relay',
    },
    content: 'El equipo debe coordinarse para completar esta parada.',
    messages: {
      hint: 'Reparte roles: mapa, pista y foto.',
      gps_unavailable: 'Al menos un jugador debe tener posición.',
      locked: 'El equipo aún no está listo.',
    },
  },
  {
    id: 'manual_password',
    title: 'Palabra clave',
    icon: '🔐',
    family: 'circuit_matrix',
    category: 'logic',
    difficulty: 'Media',
    duration: '2-5 min',
    runtimeStatus: 'planned',
    offlineStatus: 'offline_planned',
    completionMethod: 'manual_code',
    offlineNote: 'No se ofrece en plantillas jugables todavía: falta validación local de código.',
    summary: 'Resolver una palabra o código a partir de pistas.',
    playerGoal: 'Descubrir una contraseña narrativa.',
    editorHint: 'Bueno para carteles, acertijos y escape urbano.',
    config: {
      objective: 'manual_code',
      completion_method: 'manual_code',
      expected_code: 'SAGA',
      difficulty: 1,
      game_id: 'manual_password',
    },
    content: 'Encuentra la palabra clave y úsala para continuar.',
    messages: {
      hint: 'La palabra está escondida en la escena.',
      gps_unavailable: 'Este reto puede jugarse sin GPS si está desbloqueado.',
      locked: 'La palabra clave no es correcta todavía.',
    },
  },
  {
    id: 'bonus_cache',
    title: 'Bonus oculto',
    icon: '🎁',
    family: 'signal_hunt',
    category: 'physical',
    difficulty: 'Fácil',
    duration: '1-3 min',
    runtimeStatus: 'runtime_ready',
    offlineStatus: 'offline_ready',
    completionMethod: 'inventory_only',
    offlineNote:
      'Crea bonus QR en admin, se exporta, el player lo lee offline y guarda la recompensa en mochila.',
    summary: 'Extra opcional para recompensas, bromas o contenido secreto.',
    playerGoal: 'Encontrar un extra no obligatorio.',
    editorHint: 'Úsalo para dar vida al mapa sin bloquear la ruta.',
    config: {
      objective: 'bonus_cache',
      completion_method: 'inventory_only',
      game_id: 'bonus_cache',
    },
    content: 'Has encontrado un bonus oculto.',
    messages: {
      hint: 'Hay algo extra cerca.',
      gps_unavailable: 'Acércate para registrar el bonus.',
      locked: 'El bonus aún no está a tu alcance.',
    },
  },
  {
    id: 'audio_challenge',
    title: 'Desafío de audio',
    icon: '🎤',
    family: 'audio_challenge',
    category: 'motion',
    difficulty: 'Fácil',
    duration: '2-4 min',
    runtimeStatus: 'runtime_ready',
    offlineStatus: 'offline_ready',
    completionMethod: 'motion',
    offlineNote: 'El micrófono y la validación funcionan offline en local.',
    summary: 'Hacer ruido o soplar en el micrófono para cargar una barra.',
    playerGoal: 'Mantener un nivel de ruido o soplar para cargar la barra.',
    editorHint: 'Asegúrate de que los jugadores puedan usar el micrófono en su dispositivo.',
    config: {
      objective: 'blow_charge',
      game_id: 'audio_challenge',
    },
    content: 'Sopla o haz ruido cerca del micrófono para cargar la energía.',
    messages: {
      hint: 'Sopla suavemente de forma continua para llenar la barra.',
      gps_unavailable: 'Este reto puede jugarse sin GPS si está desbloqueado.',
      locked: 'Carga la barra completamente para continuar.',
    },
  },
]

export const missionTemplates: MissionTemplate[] = [
  {
    id: 'qr_route',
    title: 'Ruta QR con llave',
    icon: '🔑',
    summary: 'Juego base listo: ruta GPS, llave QR, nodo bloqueado y bonus opcional.',
    goodFor: 'Primer juego real, rutas cortas, grupos pequeños, pruebas con tarjetas físicas.',
    stages: [
      {
        gameId: 'logic_circuit',
        title: 'Inicio de ruta',
        content: 'Llega al punto inicial y activa la misión.',
        offsetLat: 0,
        offsetLon: 0,
        radius: 55,
      },
      {
        gameId: 'qr_key_gate',
        title: 'Llave del camino',
        content: 'Escanea la llave QR física.',
        offsetLat: 0.00045,
        offsetLon: 0.00028,
        radius: 45,
        physicalKind: 'requirement',
        itemLabel: 'Llave del camino',
      },
      {
        gameId: 'logic_circuit',
        title: 'Puerta bloqueada',
        content: 'Este nodo pide la llave anterior.',
        offsetLat: 0.00088,
        offsetLon: 0.00062,
        radius: 55,
        requiresPreviousItem: true,
      },
      {
        gameId: 'bonus_cache',
        title: 'Bonus final',
        content: 'Extra opcional al terminar la ruta.',
        offsetLat: 0.00118,
        offsetLon: 0.00092,
        radius: 45,
        physicalKind: 'bonus',
        itemLabel: 'Bonus final',
      },
    ],
  },
  {
    id: 'clue_hunt',
    title: 'Ruta de pistas QR',
    icon: '🧩',
    summary: 'Cadena jugable de pistas físicas y búsqueda GPS, sin puzzles pendientes.',
    goodFor: 'Misterio sencillo, historia local, juego familiar, rutas con tarjetas.',
    stages: [
      {
        gameId: 'logic_circuit',
        title: 'Punto de inicio',
        content: 'Llega al punto de salida y abre la primera pista.',
        offsetLat: 0,
        offsetLon: 0,
        radius: 55,
      },
      {
        gameId: 'clue_card',
        title: 'Pista 1',
        content: 'Escanea la primera pista QR.',
        offsetLat: 0.00042,
        offsetLon: -0.0003,
        radius: 45,
        physicalKind: 'clue',
        itemLabel: 'Pista 1',
      },
      {
        gameId: 'logic_circuit',
        title: 'Busca la señal',
        content: 'La señal se hace más fuerte al acercarte.',
        offsetLat: 0.0008,
        offsetLon: -0.00058,
        radius: 55,
      },
      {
        gameId: 'bonus_cache',
        title: 'Recompensa oculta',
        content: 'Encuentra el bonus final.',
        offsetLat: 0.00108,
        offsetLon: -0.00088,
        radius: 45,
        physicalKind: 'bonus',
        itemLabel: 'Recompensa oculta',
      },
    ],
  },
  {
    id: 'urban_escape',
    title: 'Escape QR corto',
    icon: '🔐',
    summary: 'Escape urbano simple con llave física y cierre GPS; evita pruebas aún planificadas.',
    goodFor: 'Cidade, instituto, evento corto, juego con historia sin depender de conexión.',
    stages: [
      {
        gameId: 'logic_circuit',
        title: 'Entrada',
        content: 'Activa el punto de entrada del escape.',
        offsetLat: 0,
        offsetLon: 0,
        radius: 50,
      },
      {
        gameId: 'qr_key_gate',
        title: 'Llave QR',
        content: 'Escanea la llave física para abrir la salida.',
        offsetLat: -0.0004,
        offsetLon: 0.00036,
        radius: 45,
        physicalKind: 'requirement',
        itemLabel: 'Llave QR',
      },
      {
        gameId: 'logic_circuit',
        title: 'Salida bloqueada',
        content: 'Usa la llave anterior y llega al punto de salida.',
        offsetLat: -0.00075,
        offsetLon: 0.00068,
        radius: 55,
        requiresPreviousItem: true,
      },
      {
        gameId: 'clue_card',
        title: 'Epílogo',
        content: 'Escanea la tarjeta final de historia.',
        offsetLat: -0.00105,
        offsetLon: 0.00095,
        radius: 45,
        physicalKind: 'clue',
        itemLabel: 'Epílogo',
      },
    ],
  },
  {
    id: 'family_gymkhana',
    title: 'Gymkhana familiar',
    icon: '🎁',
    summary: 'Ritmo variado con mosaico, lógica, objeto QR y bonus, todo jugable offline.',
    goodFor: 'Niños, familias, grupos pequeños, parques y rutas sencillas.',
    stages: [
      {
        gameId: 'logic_circuit',
        title: 'Punto de salida',
        content: 'Empieza la gymkhana.',
        offsetLat: 0,
        offsetLon: 0,
        radius: 60,
      },
      {
        gameId: 'place_mosaic',
        title: 'Observa el lugar',
        content: 'Reconstruye la imagen usando el elemento real como referencia.',
        offsetLat: 0.00035,
        offsetLon: 0.00035,
        radius: 55,
      },
      {
        gameId: 'qr_collectible',
        title: 'Objeto del equipo',
        content: 'Escanea el objeto QR del equipo.',
        offsetLat: 0.00065,
        offsetLon: 0.0007,
        radius: 45,
        physicalKind: 'collectible',
        itemLabel: 'Objeto del equipo',
      },
      {
        gameId: 'bonus_cache',
        title: 'Regalo oculto',
        content: 'Busca el bonus final.',
        offsetLat: 0.00095,
        offsetLon: 0.00105,
        radius: 45,
        physicalKind: 'bonus',
        itemLabel: 'Regalo oculto',
      },
    ],
  },
]

export function getAdminGame(gameId?: string | null): AdminGameCatalogItem {
  return adminGameCatalog.find((game) => game.id === gameId) || adminGameCatalog[0]
}

export function getAdminGameForStage(
  type?: string | null,
  config?: Record<string, unknown> | null
): AdminGameCatalogItem {
  const gameId = typeof config?.game_id === 'string' ? config.game_id : ''
  let explicit = adminGameCatalog.find((game) => game.id === gameId)
  if (explicit) return explicit

  explicit = adminGameCatalog.find((game) => game.id === type)
  if (explicit) return explicit

  // Legacy: signal_hunt sin game_id ya no debe caer en QR físico.
  if (type === 'signal_hunt') {
    return (
      adminGameCatalog.find((game) => game.id === 'shake_antenna_charge') || adminGameCatalog[0]
    )
  }

  return (
    adminGameCatalog.find((game) => game.family === type && game.category !== 'physical') ||
    adminGameCatalog.find((game) => game.family === type) ||
    adminGameCatalog[0]
  )
}

export function getMissionTemplateById(templateId: MissionTemplateId): MissionTemplate {
  return missionTemplates.find((template) => template.id === templateId) || missionTemplates[0]
}

export function getDefaultAdminStagePatchForGame(gameId: AdminGameId) {
  const game = getAdminGame(gameId)
  const config: Record<string, unknown> = {
    ...(game.id === 'sequence_code' ? {} : getDefaultAdminConfigForFamily(game.family)),
    ...game.config,
    game_id: game.id,
    game_title: game.title,
  }

  return {
    type: game.family,
    label: game.title,
    icon: getAdminFamilyIcon(game.family),
    objective: String((config as Record<string, unknown>).objective || ''),
    content: game.content,
    config,
    config_summary: Object.keys(config),
    messages: game.messages,
  }
}

export function getRuntimeFamilyCopy(family: FamilyId) {
  return `${getAdminFamilyIcon(family)} ${getAdminFamilyLabel(family)}`
}
